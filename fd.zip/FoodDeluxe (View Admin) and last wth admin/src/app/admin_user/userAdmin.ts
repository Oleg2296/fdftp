export const Admin: any = {
    login: 'oleg',
    password: '123'
};
