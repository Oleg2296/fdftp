"use strict";
exports.Admin = {
    login: 'oleg',
    password: '123'
};
//# sourceMappingURL=userAdmin.js.map