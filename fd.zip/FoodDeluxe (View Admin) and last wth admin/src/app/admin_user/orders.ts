export class Order {
    private id: number;
    private user: any;
    private date: any;
    private order: any;
    private amount: number;
    constructor(id: number, user: any, date: any, order: any, amount: number){
        this.id = id;
        this.user = user;
        this.date = date;
        this.order = order;
        this.amount = amount;
    }
}


export let Orders: any = [

]