"use strict";
var Order = (function () {
    function Order(id, user, date, order, amount) {
        this.id = id;
        this.user = user;
        this.date = date;
        this.order = order;
        this.amount = amount;
    }
    return Order;
}());
exports.Order = Order;
exports.Orders = [];
//# sourceMappingURL=orders.js.map