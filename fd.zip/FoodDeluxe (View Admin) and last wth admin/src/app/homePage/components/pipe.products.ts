import {Pipe} from '@angular/core';


@Pipe({
    name: 'PipeProduct'
})
export class PipeProduct{


    transform(value : any , args : any) {
        if(!args){
            return [];
        }
        return value.filter((product: any)=> {
            return product.subCategory.id == args;
        });

    }
}