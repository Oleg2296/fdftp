import {
    Component, OnChanges, Input,
    trigger, state, animate, transition, style
    ,  OnInit
} from '@angular/core';
import { AdminFunck } from '../../service/admin_func.service'

@Component({
    moduleId: module.id,
    selector: 'home-navbar',
    templateUrl: '../../../templetes/components/_navbar.html',
    animations: [

        trigger('focusPanel', [
            state('inactive', style({
                height: '0px'
            })),
            state('active', style({
                height: '35vh'
            })),
            transition('inactive => active', animate('500ms ease-in')),
            transition('active => inactive', animate('300ms ease-out'))
        ]),
    ]
})

export class NavbarComponent implements OnInit{

    state: string = 'inactive';
    private lengOrd: any[];
    state2: string = 'inactive';
    constructor(private adminFunk: AdminFunck ){}

    getLength(length:any){
        console.log(length);
        this.lengOrd=length;
    }

    toggleMove() {
        this.state = (this.state === 'inactive' ? 'active' : 'inactive');
    }

    toggleMove2() {
        this.state2 = (this.state2 === 'inactive' ? 'active' : 'inactive');

    }

    ngOnInit(){
        this.lengOrd=this.adminFunk.getOrdProd();
    }



};
