import {
    Component, OnChanges, Input,
    trigger, state, animate, transition, style
    , OnInit, Output, EventEmitter,
} from '@angular/core';
import { AdminFunck } from '../../service/admin_func.service'

@Component({
    moduleId: module.id,
    selector: 'home-cart',
    templateUrl: '../../../templetes/components/cart.html',
    animations: [
            trigger('flyInOut', [
            state('active', style({transform: 'translateX(0)'})),
            state('inactive', style({transform: 'translateX(200%)'})),
            transition('inactive => active', animate('500ms ease-in')),
            transition('active => inactive', animate('300ms ease-out'))
        ]),
    ]
})

export class CartComponent implements OnInit{


    private orders: any[];
    private price: any = {
        price: 0
    }

    check(){
        if(this.price){
            return true;
        }else{
            return false
        }
    }


    constructor(private adminFank: AdminFunck){}


    @Input()
    state2:string;
    @Output() stateUpdate = new EventEmitter();


    countUp(ord:any){
        ord.count++;
        this.price.price+=ord.price;
    }

    countDown(ord:any){
        if(ord.count>0)
        ord.count--;
        this.price.price-=ord.price;
    }


    doneOrd(){
        this.adminFank.goDoOrder();
    }

    deleteOrder(order:any){
        this.price.price-=order.price*order.count;
        this.adminFank.deleteOrderProd(order)
    }

    toggleMove() {
        this.stateUpdate.emit()
    }

    ngOnInit(){
        this.price = this.adminFank.getPrice();
        this.orders = this.adminFank.getOrdProd();
    }
}