import {Pipe} from '@angular/core';

@Pipe({
    name: 'PipeCategory'
})
export class PipeCategory{
    transform(value : any , args : any) {
        if(!args){
            return [];
        }
        return value.filter((product: any)=> {
            return product.category.id == args;
        });
    }

}