"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var admin_func_service_1 = require('../../service/admin_func.service');
var CartComponent = (function () {
    function CartComponent(adminFank) {
        this.adminFank = adminFank;
        this.price = {
            price: 0
        };
        this.stateUpdate = new core_1.EventEmitter();
    }
    CartComponent.prototype.check = function () {
        if (this.price) {
            return true;
        }
        else {
            return false;
        }
    };
    CartComponent.prototype.countUp = function (ord) {
        ord.count++;
        this.price.price += ord.price;
    };
    CartComponent.prototype.countDown = function (ord) {
        if (ord.count > 0)
            ord.count--;
        this.price.price -= ord.price;
    };
    CartComponent.prototype.doneOrd = function () {
        this.adminFank.goDoOrder();
    };
    CartComponent.prototype.deleteOrder = function (order) {
        this.price.price -= order.price * order.count;
        this.adminFank.deleteOrderProd(order);
    };
    CartComponent.prototype.toggleMove = function () {
        this.stateUpdate.emit();
    };
    CartComponent.prototype.ngOnInit = function () {
        this.price = this.adminFank.getPrice();
        this.orders = this.adminFank.getOrdProd();
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], CartComponent.prototype, "state2", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], CartComponent.prototype, "stateUpdate", void 0);
    CartComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'home-cart',
            templateUrl: '../../../templetes/components/cart.html',
            animations: [
                core_1.trigger('flyInOut', [
                    core_1.state('active', core_1.style({ transform: 'translateX(0)' })),
                    core_1.state('inactive', core_1.style({ transform: 'translateX(200%)' })),
                    core_1.transition('inactive => active', core_1.animate('500ms ease-in')),
                    core_1.transition('active => inactive', core_1.animate('300ms ease-out'))
                ]),
            ]
        }), 
        __metadata('design:paramtypes', [admin_func_service_1.AdminFunck])
    ], CartComponent);
    return CartComponent;
}());
exports.CartComponent = CartComponent;
//# sourceMappingURL=cart.component.js.map