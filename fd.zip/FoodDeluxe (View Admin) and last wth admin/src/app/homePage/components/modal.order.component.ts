import { Component, OnInit } from '@angular/core';
import { ElementRef, NgZone,  ViewChild } from '@angular/core';
import { AdminFunck } from "../../service/admin_func.service";
import { FormControl } from "@angular/forms";
import { MapsAPILoader } from 'angular2-google-maps/core';

@Component({
    moduleId: module.id,
    selector: 'modal-order',
    templateUrl: '../../../templetes/components/modal.order.html',
})

export class ModalComponent implements OnInit{

    public address : Object;
    public named ='';
    private price:any ={
        price: 0
    }
    private order: any = {
        user: {},
        commodities: [
            {
                id_commodity: 0,
                count: 0
            }
        ]
    };
    private orderList:any;
    public latitude: number;
    public longitude: number;
    public searchControl: FormControl;
    public zoom: number;
    private doneOrder: any = {
        done: true
    }

    @ViewChild("search")
    public searchElementRef: ElementRef;


    show(any:any){
        alert(any);
    }


    constructor(private adminFunck: AdminFunck, private mapsAPILoader: MapsAPILoader,
                private ngZone: NgZone){}

    getPrice(){
        for(var i in this.orderList){
            this.price+=this.orderList[i].count*this.orderList[i].price;
        }
    }


    // doneOrd(){
    //     this.adminFunck.goDoOrder2();
    // }


    toDoOrder(name:string,sname:string,number:number,adress:string){
        this.order.archive=false;
        this.order.user.name=name;
        this.order.user.surName=sname;
        this.order.user.number=number;
        this.order.user.adress=adress;
        this.order.commodities=[];
        for(let i in this.orderList){
            this.order.commodities[i]=new Object();
            this.order.commodities[i].id_commodity =this.orderList[i].id;
            this.order.commodities[i].count =this.orderList[i].count;
        }
        this.adminFunck.addOrder(this.order);
    }

    getCount(){
        this.price=this.adminFunck.getPrice();
    }

    ngOnInit(){
        this.orderList=this.adminFunck.getOrdProd();
        this.price=this.adminFunck.getPrice();
        this.doneOrder=this.adminFunck.doneOrd();
        //set google maps defaults
        this.zoom = 4;
        this.latitude = 39.8282;
        this.longitude = -98.5795;

        //create search FormControl
        this.searchControl = new FormControl();

        //set current position
        this.setCurrentPosition();

        //load Places Autocomplete
        this.mapsAPILoader.load().then(() => {
            let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
                types: ["address"]
            });
            autocomplete.addListener("place_changed", () => {
                this.ngZone.run(() => {
                    //get the place result
                    let place: google.maps.places.PlaceResult = autocomplete.getPlace();

                    //verify result
                    if (place.geometry === undefined || place.geometry === null) {
                        return;
                    }

                    //set latitude, longitude and zoom
                    this.latitude = place.geometry.location.lat();
                    this.longitude = place.geometry.location.lng();
                    this.zoom = 15;
                });
            });
        });
    }

    private setCurrentPosition() {
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition((position) => {
                this.latitude = position.coords.latitude;
                this.longitude = position.coords.longitude;
                this.zoom = 15;
            });
        }
    }


}