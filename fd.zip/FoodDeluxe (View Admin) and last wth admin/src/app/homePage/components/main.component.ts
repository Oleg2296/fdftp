import { Component, OnInit } from '@angular/core';
import { AdminFunck } from '../../service/admin_func.service';
import {products} from "../../adminPage/products/products";

@Component({
    moduleId: module.id,
    selector: 'home-main',
    templateUrl: '../../../templetes/components/_main.html'
})
export class MainComponent implements OnInit{
    private Product: any[]=[];


    constructor(private adminFunck: AdminFunck){}


    goFilter(prod:any){
        this.adminFunck.setFilterFromMain(prod);
    }

    ngOnInit(){
        this.adminFunck.getProducts().then(data => {
           for(let i=0; i<4;i++){
               // this.Product[i] = data[Math.floor(Math.random()*data.length-1)];
               this.Product[i] = data[i];
           }
        })


    }

}