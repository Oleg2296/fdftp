import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'home-footer',
    templateUrl: '../../../templetes/components/_footer.html'
})

export class FooterComponent {

}