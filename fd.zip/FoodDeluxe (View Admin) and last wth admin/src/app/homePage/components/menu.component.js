"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var admin_func_service_1 = require('../../service/admin_func.service');
var MenuComponent = (function () {
    function MenuComponent(adminFunk) {
        this.adminFunk = adminFunk;
        this.orderprod = {
            name: '',
            description: '',
            price: '',
            weight: ''
        };
    }
    MenuComponent.prototype.filterProd = function (cat) {
        for (var i in this.subCategories) {
            if (this.subCategories[i].category.id == cat.id) {
                return this.subCategories[i].id;
            }
        }
    };
    MenuComponent.prototype.checkProd = function (prod) {
        this.link = "http://localhost:8080/resources/img/" + prod.img;
        this.orderprod = prod;
        console.log(this.orderprod.img);
    };
    MenuComponent.prototype.pushOrder = function (order) {
        if (!order) {
            this.adminFunk.pushOrds(this.orderprod);
        }
        else {
            this.adminFunk.pushOrds(order);
        }
    };
    MenuComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.adminFunk.getProducts().then(function (data) {
            _this.products = data;
        });
        this.adminFunk.getCategories().then(function (data) {
            _this.categories = data;
        });
        this.adminFunk.getSubCategories().then(function (data) { _this.subCategories = data; });
        this.adminFunk.getSubId().then(function (data) {
            if (_this.adminFunk.getMainFilter()) {
                _this.sort = _this.adminFunk.getMainFilter().subCategory.id;
                _this.catsort = _this.adminFunk.getMainFilter().subCategory.category.id;
            }
            else {
                _this.sort = data.id;
                _this.catsort = data.category.id;
            }
        });
    };
    MenuComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'home-menu',
            templateUrl: '../../../templetes/components/_menu.html'
        }), 
        __metadata('design:paramtypes', [admin_func_service_1.AdminFunck])
    ], MenuComponent);
    return MenuComponent;
}());
exports.MenuComponent = MenuComponent;
//# sourceMappingURL=menu.component.js.map