import { Component, OnInit } from '@angular/core';

import { AdminFunck } from '../../service/admin_func.service'

@Component({
    moduleId: module.id,
    selector: 'home-menu',
    templateUrl: '../../../templetes/components/_menu.html'
})

export class MenuComponent implements OnInit {

    private products: any[];
    private subCategories: any[];
    private categories: any[];
    private catsort: number;
    private sort: any;
    private link: string;

    private orderprod: any = {
        name: '',
        description: '',
        price: '',
        weight: ''
    };


    constructor(private adminFunk: AdminFunck){}

    filterProd(cat: any){
        for(let i in this.subCategories){
            if(this.subCategories[i].category.id==cat.id){
                return this.subCategories[i].id;
            }
        }
    }


    checkProd(prod:any){

        this.link = "http://localhost:8080/resources/img/"+prod.img;
        this.orderprod = prod;
        console.log(this.orderprod.img);
    }

    pushOrder(order:any){
        if(!order){
            this.adminFunk.pushOrds(this.orderprod);
        }else{
            this.adminFunk.pushOrds(order);
        }

    }

    ngOnInit(){
        this.adminFunk.getProducts().then(data=>{
            this.products = data;
        })
        this.adminFunk.getCategories().then(data=>{
            this.categories =data;
        })
        this.adminFunk.getSubCategories().then(data =>{this.subCategories=data;});
        this.adminFunk.getSubId().then((data: any) => {
            if(this.adminFunk.getMainFilter()){
                this.sort = this.adminFunk.getMainFilter().subCategory.id;
                this.catsort = this.adminFunk.getMainFilter().subCategory.category.id;
            }else {
                this.sort = data.id;
                this.catsort = data.category.id
            }

        })
    }
}