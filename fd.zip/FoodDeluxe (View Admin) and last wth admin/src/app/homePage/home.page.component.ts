import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'home-page',
    template: '<home-navbar></home-navbar><router-outlet></router-outlet><home-footer></home-footer>'
})

export class HomePageComponent {

}

// <home-main></home-main>
// <home-menu></home-menu>