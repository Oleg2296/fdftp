import { Component, OnInit } from '@angular/core';
import { LoginAdminService } from './loginAdmin.service';
import { Router } from '@angular/router';
import { UserService } from '../service/user.service';
import { HttpClient } from '../service/http.service';
import { AuthService } from '../service/auth.service';


@Component({
    moduleId: module.id,
    selector: 'login-admin',
    templateUrl: '../../templetes/views/loginAdmin.html',
    styleUrls: ['../../style/layout/LoginAdmin.css']
})

export class LoginAdminComponent implements OnInit{
    constructor(private http: HttpClient, private router: Router, private user: UserService){}

    wrongPass:boolean;

    loginAdmin(login: any, password: any){
        let user: any = {username: login, password: password };
       this.http.loginIn(user)
           .then(()=>{
            this.router.navigate(["adminPage"]);
        })

    }

    ngOnInit(){
        this.user.checkAdmin()
    }

}