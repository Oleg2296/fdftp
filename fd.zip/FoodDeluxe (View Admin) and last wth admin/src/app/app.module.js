"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
//Modules
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var forms_1 = require('@angular/forms');
var http_1 = require('@angular/http');
var forms_2 = require("@angular/forms");
// import { ModalModule } from "ng2-modal";
var core_2 = require('angular2-google-maps/core');
//Router module
var app_router_1 = require('./app.router');
var ng2_page_scroll_1 = require('ng2-page-scroll');
//Components
// import { AddUserComponent } from './adminPage/addUsers/addUsr.component';
var app_component_1 = require('./app.component');
var loginAdmin_component_1 = require('./loginAdmin/loginAdmin.component');
var adminPage_component_1 = require('./adminPage/adminPage.component');
var orders_component_1 = require('./adminPage/orders/orders.component');
var category_component_1 = require('./adminPage/category/category.component');
var product_component_1 = require('./adminPage/products/product.component');
var subcategory_component_1 = require('./adminPage/category/subCategory/subcategory.component');
var home_page_component_1 = require('./homePage/home.page.component');
var navbar_component_1 = require('./homePage/components/navbar.component');
var main_component_1 = require('./homePage/components/main.component');
var footer_component_1 = require('./homePage/components/footer.component');
var menu_component_1 = require('./homePage/components/menu.component');
var cart_component_1 = require('./homePage/components/cart.component');
var modal_order_component_1 = require('./homePage/components/modal.order.component');
//Services
// import { AddUserService } from './adminPage/addUsers/addUser.service'
var http_service_1 = require('./service/http.service');
var user_service_1 = require('./service/user.service');
var auth_service_1 = require('./service/auth.service');
var admin_func_service_1 = require('./service/admin_func.service');
//Filters
var products_pipe_1 = require('./adminPage/products/products.pipe');
var order_pipe_1 = require('./adminPage/orders/order.pipe');
var serch_pipe_order_1 = require('./adminPage/orders/serch.pipe.order');
var pipe_search_1 = require('./adminPage/products/pipe.search');
var pipe_products_1 = require('./homePage/components/pipe.products');
var pipe_category_1 = require('./homePage/components/pipe.category');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, http_1.HttpModule, app_router_1.AppRoutingModule, ng2_page_scroll_1.Ng2PageScrollModule.forRoot(), core_2.AgmCoreModule.forRoot({
                    libraries: ["places"],
                    apiKey: "AIzaSyC8r1Rdnau0NpihEJXKEo4EaHwwtNdEQJo"
                }), platform_browser_1.BrowserModule,
                forms_2.ReactiveFormsModule],
            declarations: [app_component_1.AppComponent, loginAdmin_component_1.LoginAdminComponent, adminPage_component_1.AdminPageComponent, orders_component_1.OrdersComponent, category_component_1.CategoryComponent, product_component_1.ProductComponent, subcategory_component_1.SubcategoryComponent, products_pipe_1.MyPipe, order_pipe_1.SortPipe, serch_pipe_order_1.MovieFilterPipe, footer_component_1.FooterComponent, pipe_search_1.SearchProdPipe, main_component_1.MainComponent, home_page_component_1.HomePageComponent, navbar_component_1.NavbarComponent, menu_component_1.MenuComponent, cart_component_1.CartComponent, pipe_products_1.PipeProduct, pipe_category_1.PipeCategory, modal_order_component_1.ModalComponent],
            providers: [user_service_1.UserService, http_service_1.HttpClient, auth_service_1.AuthService, admin_func_service_1.AdminFunck],
            bootstrap: [app_component_1.AppComponent]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map