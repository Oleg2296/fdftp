export class Category {
    private id: number;
    public name: string;
    constructor(id :number, name: string){
        this.id=id;
        this.name=name;
    }
}

export let categories: Category[] = [
    // new Category(1,'sup'),
    // new Category(2,'pershe'),
    // new Category(3,'pizza'),
    // new Category(4,'burgers'),
    // new Category(5,'voda'),
    // new Category(6,'alckho')
]

export class Subcategory {
    private id: number;
    private category: string;
    public name: string;
    constructor(id: number, category: string, name: string){
        this.id = id;
        this.category = category;
        this.name = name;
    }
}

export let subcategories: Subcategory[] = [
        // new Subcategory(1,this.categories[0].name, 'bulochka'),
//         new Subcategory(2,this.categories[2].name, 'pechevo'),
//         new Subcategory(3,this.categories[2].name, 'doroblay'),
//         new Subcategory(4,this.categories[5].name, 'konope'),
//         new Subcategory(5,this.categories[4].name, 'golochki'),
//         new Subcategory(6,this.categories[4].name, 'lisia')
]
