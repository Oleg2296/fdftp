import { Component, OnInit } from '@angular/core';

//services
import { AdminFunck } from '../../service/admin_func.service';
import { UserService } from '../../service/user.service';
import { HttpClient } from '../../service/http.service';


@Component({
    moduleId: module.id,
    selector: 'category',
    templateUrl: '../../../templetes/views/category.html',
    styleUrls: ['../../../style/layout/category.css']
})

export class CategoryComponent implements OnInit{

    private category: any;
    private editCategor: any = {
        id: '',
        name: ''
    }

    private addCat: any;


    constructor(private adminFunck: AdminFunck, private userService: UserService, private http: HttpClient){}

    editCategory(category: any){
        let obj = Object.assign({}, category);
        this.editCategor = obj;
    }

    editSaveCategory(name: string){
        this.editCategor.name = name;
        this.adminFunck.updateCategory(this.editCategor);
    }

    addCategory(name: string){
       this.addCat = {
            name: name
        };
        this.adminFunck.addCategory(this.addCat);
    }

    deleteCategory(id: any){
        this.adminFunck.deleteCategory(id);
    }

    ngOnInit(){
        this.userService.checkAdmin();
        this.adminFunck.getCategories().then(data=>{
            this.category =data;
        })
    }


}
