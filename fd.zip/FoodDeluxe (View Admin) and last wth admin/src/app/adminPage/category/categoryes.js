"use strict";
var Category = (function () {
    function Category(id, name) {
        this.id = id;
        this.name = name;
    }
    return Category;
}());
exports.Category = Category;
exports.categories = [];
var Subcategory = (function () {
    function Subcategory(id, category, name) {
        this.id = id;
        this.category = category;
        this.name = name;
    }
    return Subcategory;
}());
exports.Subcategory = Subcategory;
exports.subcategories = [];
//# sourceMappingURL=categoryes.js.map