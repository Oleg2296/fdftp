"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var admin_func_service_1 = require('../../../service/admin_func.service');
var user_service_1 = require('../../../service/user.service');
var SubcategoryComponent = (function () {
    function SubcategoryComponent(adminFunck, userService) {
        this.adminFunck = adminFunck;
        this.userService = userService;
        this.editSubCategory = {
            id: '',
            category: {
                name: ''
            },
            name: ''
        };
    }
    SubcategoryComponent.prototype.addSubCategory = function (id, name) {
        this.addSubCat = {
            category: +id,
            name: name,
        };
        this.adminFunck.addSubCategory(this.addSubCat);
    };
    SubcategoryComponent.prototype.editSubCat = function (subcat) {
        var obj = Object.assign({}, subcat);
        this.editSubCategory = obj;
    };
    SubcategoryComponent.prototype.editSaveSubCat = function (name, category) {
        for (var i in this.categories) {
            if (category == this.categories[i].name) {
                this.editSubCategory.category = this.categories[i].id;
            }
        }
        this.editSubCategory.name = name;
        this.adminFunck.updateSubcategory(this.editSubCategory);
    };
    SubcategoryComponent.prototype.deleteSubCategory = function (subId) {
        this.adminFunck.deleteSubCategory(subId);
    };
    SubcategoryComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.checkAdmin();
        this.adminFunck.getCategories().then(function (data) {
            _this.categories = data;
        });
        this.adminFunck.getSubCategories().then(function (data) { _this.subCategory = data; });
        // console.assert(this.categories)
    };
    SubcategoryComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'subCategory',
            templateUrl: '../../../../templetes/views/subCategory.html',
            styleUrls: ['../../../../style/layout/subcategory.css']
        }), 
        __metadata('design:paramtypes', [admin_func_service_1.AdminFunck, user_service_1.UserService])
    ], SubcategoryComponent);
    return SubcategoryComponent;
}());
exports.SubcategoryComponent = SubcategoryComponent;
//# sourceMappingURL=subcategory.component.js.map