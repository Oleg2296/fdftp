import { Component, OnInit } from '@angular/core';
import { AdminFunck } from '../../../service/admin_func.service';
import { UserService } from '../../../service/user.service';


@Component({
    moduleId: module.id,
    selector: 'subCategory',
    templateUrl: '../../../../templetes/views/subCategory.html',
    styleUrls: ['../../../../style/layout/subcategory.css']
})


export class SubcategoryComponent implements OnInit{
    private subCategory: any;
    private categories: any;
    private addSubCat: any;
    private idSub: number;
    private editSubCategory: any = {
        id: '',
        category: {
            name: ''
        },
        name: ''
    }

    constructor(private adminFunck: AdminFunck, private userService: UserService){}

    addSubCategory(id:number, name: string){
        this.addSubCat = {
            category: +id,
            name: name,
        }
        this.adminFunck.addSubCategory(this.addSubCat);
    }

    editSubCat(subcat: any){
        let obj = Object.assign({}, subcat);
        this.editSubCategory = obj;
    }

    editSaveSubCat(name: string, category:string){
        for(let i in this.categories){
            if(category==this.categories[i].name){
                this.editSubCategory.category= this.categories[i].id;
            }
        }
        this.editSubCategory.name = name;
        this.adminFunck.updateSubcategory(this.editSubCategory);
    }

    deleteSubCategory(subId: any){
        this.adminFunck.deleteSubCategory(subId);
    }
    ngOnInit(){
        this.userService.checkAdmin();
        this.adminFunck.getCategories().then(data=>{
            this.categories =data;
        })
        this.adminFunck.getSubCategories().then(data =>{this.subCategory=data});
        // console.assert(this.categories)
    }

}