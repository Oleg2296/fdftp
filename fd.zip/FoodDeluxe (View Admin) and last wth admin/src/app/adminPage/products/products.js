"use strict";
var Product = (function () {
    function Product(id, category, subcat, name, price) {
        this.id = id;
        this.category = category;
        this.subcats = subcat;
        this.name = name;
        this.price = price;
    }
    return Product;
}());
exports.Product = Product;
exports.products = [];
//# sourceMappingURL=products.js.map