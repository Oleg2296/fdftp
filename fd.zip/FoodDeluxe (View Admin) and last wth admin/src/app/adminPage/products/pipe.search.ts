import {Pipe, PipeTransform} from '@angular/core';
@Pipe({
    name: 'SearchProduct'
})
export class SearchProdPipe implements PipeTransform {
    transform(items: any[], args:any): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        if(!args){
            return items;
        }
        return items.filter(item => {
            if(item.subCategory.category.name.indexOf(args) == -1 && item.subCategory.name.indexOf(args) == -1 && item.name.indexOf(args) == -1 && item.description.indexOf(args) == -1){
                return false;
            }
            return true;
        });
    }
}