import {Pipe} from '@angular/core';

@Pipe({
    name: 'MyPipe'
})
export class MyPipe{
    transform(value : any , args : any) {
        if(!args){
            return [];
        }
        return value.filter((subcategory: any)=> {
            return subcategory.category.name == args;
        });
    }

}