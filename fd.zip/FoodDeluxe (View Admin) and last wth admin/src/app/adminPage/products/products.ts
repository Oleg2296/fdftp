import { categories, Category, subcategories, Subcategory } from '../category/categoryes';



export class Product {
    private id: number;
    private category: string;
    private subcats: string;
    private name: string;
    private price: number;
    constructor(id: number, category: string,subcat: string, name: string, price: number){
        this.id = id;
        this.category = category;
        this.subcats = subcat;
        this.name = name;
        this.price = price;
    }
}

export let products: Product[] = [
    // new Product(1,categories[1].name,subcategories[1].name,'gamburhger',26),
    // new Product(2,categories[2].name,subcategories[2].name,'gamburhger',26),
    // new Product(3,categories[0].name,subcategories[3].name,'gamburhger',26),
    // new Product(4,categories[3].name,subcategories[4].name,'pomidorchik',26),
    // new Product(5,categories[2].name,subcategories[0].name,'kayene',26)
]
