import {Component, OnInit} from '@angular/core';

import {AdminFunck} from '../../service/admin_func.service';
import {UserService} from '../../service/user.service';

import {MyPipe} from './products.pipe';


@Component({
    moduleId: module.id,
    selector: 'prodct',
    templateUrl: '../../../templetes/views/products.html',
    styleUrls: ['../../../style/layout/products.css']
})

export class ProductComponent implements OnInit {
    private products: any[];
    private idProd: number;
    private categories: any[];
    private subcategories: any[];
    private cutFilter: any;
    private searchFilter: any;
    private image: any;
    private editProd: any = this.getPr();
    private sort: any;

    constructor(private adminFunck: AdminFunck, private userService: UserService) {
    }

    addProduct(subcat: string, name: string, price: number, weight:string, desc: string) {
        let prod: any = {
            subCategory: subcat,
            name: name,
            price: price,
            weight: weight,
            description: desc,
            img: this.image
        }
        this.adminFunck.addProduct(prod);
        this.image = '';
    }

    deleteProd(prod: any) {
        this.adminFunck.delitProduct(prod);
    }

    editProduct(prod: any) {
        let obj = Object.assign({}, prod);
        this.editProd = obj;
    }

    changeListener($event:any) : void {
        this.readThis($event.target);
    }

    readThis(inputValue: any): void {
        var file:File = inputValue.files[0];
        var myReader:FileReader = new FileReader();

        myReader.onloadend = (e) => {
            this.image = myReader.result;
        }
        myReader.readAsDataURL(file);
    }


    getPr() {
       return {
           id: '',
           category: '',
           subCategory: {
               name: '',
               category: {
                   name: ''
               }
           },
           name: '',
           price: ''
       }
    }


    editSaveProduct(subcat: string, name: string, price: number,weight:number,descr:string) {
        for(let i in this.subcategories){
            if(subcat==this.subcategories[i].name){
                this.editProd.subCategory= this.subcategories[i].id;
            }
        }

        this.editProd.name = name;
        this.editProd.price = +price;
        this.editProd.weight = +weight;
        this.editProd.description=descr;
        if(!this.image){
            this.editProd.img=null;
        }else{
            this.editProd.img=this.image;
        }

        // console.log(this.editProd);
        this.adminFunck.editSaveProduct(this.editProd);
        this.editProd = this.getPr();

    }


    ngOnInit() {
        this.userService.checkAdmin();
        this.adminFunck.getProducts().then(data=>{
            this.products =data;
        })
        this.adminFunck.getCategories().then(data=>{
            this.categories =data;
        })
        this.subcategories = [{

        }]
        this.adminFunck.getSubCategories().then(data =>{
            this.subcategories=data;

            }
        )
    }

}

