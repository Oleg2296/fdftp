/*
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/toPromise';

import { UserService } from '../../service/user.service';
import { AdminFunck } from '../../service/admin_func.service';


@Injectable()

export class AddUserService {


    constructor(private userService: UserService, private adminFunck: AdminFunck){
    }

    addUsr(user: any){
        this.adminFunck.addUser(user);
    }

    delete(user: any){
        this.adminFunck.delete(user);
    }

}
    */ 
//# sourceMappingURL=addUser.service.js.map