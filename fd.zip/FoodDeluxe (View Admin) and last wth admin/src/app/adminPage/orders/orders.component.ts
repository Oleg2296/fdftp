import { Component, OnInit, ViewChild, Input  } from '@angular/core';
import { UserService } from '../../service/user.service';
import { AdminFunck } from '../../service/admin_func.service';
import {products} from "../products/products";

@Component({
    moduleId: module.id,
    selector: 'my-order',
    templateUrl: '../../../templetes/views/orders_in_admin.html',
    styleUrls: ['../../../style/layout/orders_admin.css']
})

export class OrdersComponent implements OnInit{

    private orders: any;
    private archOrds: any;
    private order: any;
    private searchFilter: any;
    private products:any;
    private choose:any=[];






    constructor(private adminFunk: AdminFunck, private userService: UserService) {}


    unArchiveOrd(order: any){
        this.adminFunk.unArchOrder(order);
    }

    archOrd(ord:any){
        this.adminFunk.archOrder(ord);
    }

    showOrder(dish:any){
        this.choose=[];
        for(let i in this.products){
            for(let j in dish.commodities){
                if(this.products[i].id==dish.commodities[j].id_commodity){
                    this.products[i].count=dish.commodities[j].count;
                    this.choose.push(this.products[i]);
                }
            }

        }
        return this.choose;
    }

    deleteOrder(id:any){
        this.adminFunk.deleteOrder(id);

    }


    ngOnInit() {
        this.userService.checkAdmin();
        this.adminFunk.getProducts().then(data=>{this.products = data})
       this.adminFunk.getOrders().then(data=>{ this.orders = data;});
        this.archOrds = this.adminFunk.getArchOrd();
    }

}