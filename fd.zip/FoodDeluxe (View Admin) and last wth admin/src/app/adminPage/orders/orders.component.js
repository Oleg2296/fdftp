"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_service_1 = require('../../service/user.service');
var admin_func_service_1 = require('../../service/admin_func.service');
var OrdersComponent = (function () {
    function OrdersComponent(adminFunk, userService) {
        this.adminFunk = adminFunk;
        this.userService = userService;
        this.choose = [];
    }
    OrdersComponent.prototype.unArchiveOrd = function (order) {
        this.adminFunk.unArchOrder(order);
    };
    OrdersComponent.prototype.archOrd = function (ord) {
        this.adminFunk.archOrder(ord);
    };
    OrdersComponent.prototype.showOrder = function (dish) {
        this.choose = [];
        for (var i in this.products) {
            for (var j in dish.commodities) {
                if (this.products[i].id == dish.commodities[j].id_commodity) {
                    this.products[i].count = dish.commodities[j].count;
                    this.choose.push(this.products[i]);
                }
            }
        }
        return this.choose;
    };
    OrdersComponent.prototype.deleteOrder = function (id) {
        this.adminFunk.deleteOrder(id);
    };
    OrdersComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.checkAdmin();
        this.adminFunk.getProducts().then(function (data) { _this.products = data; });
        this.adminFunk.getOrders().then(function (data) { _this.orders = data; });
        this.archOrds = this.adminFunk.getArchOrd();
    };
    OrdersComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'my-order',
            templateUrl: '../../../templetes/views/orders_in_admin.html',
            styleUrls: ['../../../style/layout/orders_admin.css']
        }), 
        __metadata('design:paramtypes', [admin_func_service_1.AdminFunck, user_service_1.UserService])
    ], OrdersComponent);
    return OrdersComponent;
}());
exports.OrdersComponent = OrdersComponent;
//# sourceMappingURL=orders.component.js.map