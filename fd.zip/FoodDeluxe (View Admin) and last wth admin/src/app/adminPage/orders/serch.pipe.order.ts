import {Pipe, PipeTransform} from '@angular/core';
@Pipe({
    name: 'SearchOrder'
})
export class MovieFilterPipe implements PipeTransform {
    transform(items: any[], args:any): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        if(!args){
            return items;
        }
        return items.filter(item => {
            if(item.user.name.indexOf(args) == -1 && item.user.surName.indexOf(args) == -1 && item.user.number.indexOf(args) == -1 && item.user.adress.indexOf(args) == -1){
                return false;
            }
            return true;
        });
    }
}