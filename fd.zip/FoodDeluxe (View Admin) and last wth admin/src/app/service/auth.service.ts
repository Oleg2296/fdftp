import { Injectable } from '@angular/core'
import { HttpClient } from './http.service';
import {Http,Headers, RequestOptions} from '@angular/http';

import 'rxjs/add/operator/toPromise';


@Injectable()

export class AuthService {

    private token:string;

    constructor(private http: Http){}

    signIn(url:string,user: any):Promise<any>{
        return this.http.post(url, user).toPromise()
    }

    createAuthorizationHeader(headers:Headers) {
        if(!this.token)
            this.token=localStorage.getItem('currentUser');
        headers.append('X-Auth-Token', this.token);
    }

    setToken(token: string){
        localStorage.setItem('currentUser', token);
        this.token=token;
    }

    getToken():string{
        if(this.token){
            return this.token;
        }else{
            this.token=localStorage.getItem('currentUser');
            return this.token;
        }
    }

    removeToken(){
        this.token="";
        localStorage.removeItem("currentUser");
    }

    get(url:string){
        let headers = new Headers();
        this.createAuthorizationHeader(headers);
        return this.http.get(url,{
            headers: headers
        });

    }
    getOrd(url:string){
        let headers = new Headers();
        this.createAuthorizationHeader(headers);
        return this.http.get(url,{
            headers: headers
        });

    }


    delete(url: string) {
        let headers = new Headers();
        this.createAuthorizationHeader(headers);
        return this.http.delete(url, {
            headers: headers
        });
    }

    post(url: string, data: any){
        let obj = JSON.stringify(data);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        this.createAuthorizationHeader(headers);
        return this.http.post(url, obj, {
            headers: headers
        });
    }

    put(url: string, data: any) {
        let obj = JSON.stringify(data);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        this.createAuthorizationHeader(headers);
        return this.http.put(url, obj, {
            headers: headers
        });
    }


    logOut(){
        this.removeToken();
    }

}