import { Injectable } from '@angular/core'
import 'rxjs/add/operator/toPromise';

import { HttpClient } from './http.service';
import { Router } from '@angular/router';


@Injectable()

export class UserService {

    constructor(private http: HttpClient,private router: Router){}

    currentAdmin: any;

    checkAdmin(){
        // let obj = localStorage.getItem('currentUser');
        if(!this.http.getToken()){
            this.router.navigate(['loginAdmin']);
        }
    }
    logOut(){
        this.http.logOut();
    }

}
