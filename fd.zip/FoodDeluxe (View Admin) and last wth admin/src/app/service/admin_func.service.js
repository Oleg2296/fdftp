"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
require('rxjs/add/operator/toPromise');
var orders_1 = require("../admin_user/orders");
var users_1 = require('../admin_user/users');
var http_service_1 = require('./http.service');
require('rxjs/add/operator/toPromise');
var categoryes_1 = require('../adminPage/category/categoryes');
var products_1 = require('../adminPage/products/products');
var AdminFunck = (function () {
    function AdminFunck(http) {
        this.http = http;
        //Orders
        this.orders = orders_1.Orders;
        this.archOrd = [];
        //users
        this.users = users_1.users;
        //Categories
        this.categories = categoryes_1.categories;
        //subCategories
        this.subCategories = categoryes_1.subcategories;
        //products
        this.products = products_1.products;
        this.price = {
            price: 0
        };
        this.doneOrder = {
            done: true
        };
        this.ordsProd = [];
    }
    AdminFunck.prototype.doneOrd = function () {
        return this.doneOrder;
    };
    AdminFunck.prototype.goDoOrder = function () {
        if (!this.doneOrder.done) {
            this.doneOrder.done = !this.doneOrder.done;
        }
    };
    //methods with Orders in cart
    AdminFunck.prototype.deleteOrderProd = function (ord) {
        for (var i = 0; i < this.ordsProd.length; i++) {
            if (this.ordsProd[i].id == ord.id) {
                this.ordsProd.splice(i, 1);
            }
        }
    };
    AdminFunck.prototype.pushOrds = function (ord) {
        for (var i = 0; i < this.ordsProd.length; i++) {
            if (this.ordsProd[i].id == ord.id) {
                this.ordsProd[i].count++;
                this.price.price += this.ordsProd[i].price;
                return;
            }
        }
        this.price.price += ord.price;
        ord.count = 1;
        this.ordsProd.push(ord);
    };
    AdminFunck.prototype.getOrdProd = function () {
        return this.ordsProd;
    };
    AdminFunck.prototype.getPrice = function () {
        return this.price;
    };
    //METHOD with orders
    AdminFunck.prototype.getOrders = function () {
        var _this = this;
        return this.http.getOrder()
            .then(function (data) {
            var obj = JSON.parse(data["_body"]);
            for (var i = 0; i < obj.length; i++) {
                if (!obj[i].archive) {
                    _this.orders.push(obj[i]);
                }
                else {
                    _this.archOrd.push(obj[i]);
                }
            }
            return Promise.resolve(_this.orders);
        });
    };
    AdminFunck.prototype.addOrder = function (order) {
        var _this = this;
        this.http.addOrder(order)
            .then(function (data) {
            var obj = JSON.parse(data["_body"]);
            _this.orders.push(obj);
        });
    };
    AdminFunck.prototype.archOrder = function (ord) {
        var _this = this;
        this.http.archiveOrder(ord).then(function () {
            ord.archive = true;
            for (var i = 0; i < _this.orders.length; i++) {
                if (_this.orders[i].id == ord.id) {
                    _this.archOrd.push(ord);
                    _this.orders.splice(i, 1);
                }
            }
        });
    };
    AdminFunck.prototype.unArchOrder = function (ord) {
        var _this = this;
        this.http.unArchiveOrder(ord).then(function () {
            ord.archive = false;
            for (var i = 0; i < _this.archOrd.length; i++) {
                if (_this.archOrd[i].id == ord.id) {
                    _this.orders.push(ord);
                    _this.archOrd.splice(i, 1);
                }
            }
        });
    };
    AdminFunck.prototype.deleteOrder = function (id) {
        var _this = this;
        this.http.deleteOrder(id).then(function () {
            for (var i = 0; i < _this.archOrd.length; i++) {
                if (_this.archOrd[i].id == id) {
                    _this.archOrd.splice(i, 1);
                }
            }
        });
    };
    AdminFunck.prototype.getArchOrd = function () {
        return this.archOrd;
    };
    //methods with Users
    AdminFunck.prototype.delete = function (user) {
        for (var i = 0; i < this.users.length; i++) {
            if (user.name == this.users[i].name) {
                this.users.splice(i, 1);
            }
        }
    };
    AdminFunck.prototype.addUser = function (user) {
        console.log(user);
        this.users.push(user);
    };
    // method with filters
    AdminFunck.prototype.setFilterFromMain = function (prod) {
        this.MainFilter = prod;
    };
    AdminFunck.prototype.getMainFilter = function () {
        return this.MainFilter;
    };
    AdminFunck.prototype.getSubId = function () {
        var _this = this;
        return this.http.getSubCategories().then(function (data) {
            var obj = JSON.parse(data["_body"]);
            _this.subId = obj[0];
            return Promise.resolve(_this.subId);
        });
    };
    //methods with Categories
    AdminFunck.prototype.getCategories = function () {
        var _this = this;
        return this.http.getCat().then(function (data) {
            var obj = JSON.parse(data["_body"]);
            for (var i = 0; i < obj.length; i++) {
                _this.categories[i] = obj[i];
            }
            return Promise.resolve(_this.categories);
        });
    };
    AdminFunck.prototype.updateCategory = function (category) {
        var _this = this;
        this.http.updateCategory(category).then(function (data) {
            var obj = JSON.parse(data["_body"]);
            for (var i = 0; i < _this.categories.length; i++) {
                if (_this.categories[i].id == obj.id) {
                    _this.categories.splice(i, 1, obj);
                }
            }
        });
    };
    AdminFunck.prototype.addCategory = function (category) {
        var _this = this;
        this.http.addCategory(category).then(function (data) {
            var obj = JSON.parse(data["_body"]);
            _this.categories.push(obj);
        });
    };
    AdminFunck.prototype.deleteCategory = function (id) {
        var _this = this;
        this.http.deleteCategory(id)
            .then(function () {
            for (var i = 0; i < _this.categories.length; i++) {
                if (_this.categories[i].id == id) {
                    _this.categories.splice(i, 1);
                }
            }
        });
    };
    //methods whit subCategory
    AdminFunck.prototype.getSubCategories = function () {
        var _this = this;
        return this.http.getSubCategories().then(function (data) {
            var obj = JSON.parse(data["_body"]);
            for (var i = 0; i < obj.length; i++) {
                _this.subCategories[i] = obj[i];
            }
            return Promise.resolve(_this.subCategories);
        });
    };
    AdminFunck.prototype.addSubCategory = function (subCat) {
        var _this = this;
        this.http.addSubcategory(subCat).then(function (data) {
            var obj = JSON.parse(data["_body"]);
            _this.subCategories.push(obj);
        });
    };
    AdminFunck.prototype.updateSubcategory = function (sub) {
        var _this = this;
        this.http.updateSubcategory(sub)
            .then(function (data) {
            var obj = JSON.parse(data["_body"]);
            for (var i = 0; i < _this.subCategories.length; i++) {
                if (_this.subCategories[i].id == obj.id) {
                    _this.subCategories.splice(i, 1, obj);
                }
            }
        });
    };
    AdminFunck.prototype.deleteSubCategory = function (subId) {
        var _this = this;
        this.http.deleteSubCategory(subId).then(function () {
            for (var i = 0; i < _this.subCategories.length; i++) {
                if (_this.subCategories[i].id == subId) {
                    _this.subCategories.splice(i, 1);
                }
            }
        });
    };
    //method with products
    AdminFunck.prototype.getProducts = function () {
        var _this = this;
        return this.http.getProducts()
            .then(function (data) {
            var obj = JSON.parse(data["_body"]);
            for (var i in obj) {
                _this.products[i] = obj[i];
            }
            return Promise.resolve(_this.products);
        });
    };
    AdminFunck.prototype.addProduct = function (prod) {
        var _this = this;
        this.http.addProduct(prod)
            .then(function (data) {
            var obj = JSON.parse(data["_body"]);
            _this.products.push(obj);
        });
    };
    AdminFunck.prototype.delitProduct = function (prod) {
        var _this = this;
        this.http.deleteProduct(prod)
            .then(function () {
            for (var i = 0; i < _this.products.length; i++) {
                if (_this.products[i].id == prod) {
                    _this.products.splice(i, 1);
                }
            }
        });
    };
    AdminFunck.prototype.editSaveProduct = function (prod) {
        var _this = this;
        this.http.updateProduct(prod)
            .then(function (data) {
            var obj = JSON.parse(data["_body"]);
            for (var i = 0; i < _this.products.length; i++) {
                if (_this.products[i].id == obj.id) {
                    _this.products.splice(i, 1, obj);
                }
            }
        });
    };
    AdminFunck = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_service_1.HttpClient])
    ], AdminFunck);
    return AdminFunck;
}());
exports.AdminFunck = AdminFunck;
//# sourceMappingURL=admin_func.service.js.map