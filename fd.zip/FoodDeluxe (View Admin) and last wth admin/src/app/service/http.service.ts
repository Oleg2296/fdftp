import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions} from '@angular/http';

import 'rxjs/add/operator/toPromise';

import {Router} from '@angular/router';
import { AuthService } from './auth.service';

//users, admins
import {Admin} from '../admin_user/userAdmin';
import {User, users} from '../admin_user/users';
import {Category, categories} from "../adminPage/category/categoryes";


@Injectable()

export class HttpClient {
    private token: string;
    private admin: any = Admin;
    private users: User[] = users;
    private orders: any[];
    private categories: any[] = categories;
    private addCat: Category;

    // constructor(private http: Http, private router: Router) {
    // }
    constructor(private http: AuthService, private router: Router) {
    }

    post(url: string, data: any) {
        let user = data;
        if (user.login == this.admin.login && user.password == this.admin.password) {
            return true;
        } else {
            return false;
        }
    }
    //login
    loginIn(user:any):Promise<any>{
        return this.http.post('http://localhost:8080/login',user).toPromise()
            .then(data=>{
                let obj=JSON.parse(data["_body"]);
                this.http.setToken(obj.token);
            })
    }

    getToken(){
        return this.http.getToken();
    }

    //Methods with Categories
    getCat(): Promise<any> {
        return this.http.get('http://localhost:8080/categories/get').toPromise()
            .then(data => {
                return data
            })
            .catch(error => console.log(error));
    }

    addCategory(category: any): Promise<Category> {
        return this.http.put('http://localhost:8080/categories/save', category).toPromise()
            .then(data => {
                return data;
            })
            .catch(error => console.log(error))
    }

    deleteCategory(id: any): Promise<number> {
        return this.http.delete('http://localhost:8080/categories/delete/' + id).toPromise()
            .then()
            .catch(error => {
                console.log(error)
            });
    }

    updateCategory(category: Category): Promise<Category> {
        return this.http.put('http://localhost:8080/categories/update', category).toPromise()
            .then(data => {
                return data;
            })
            .catch(error => {
                console.log(error)
            })
    }

    //method with subcategories

    getSubCategories(): Promise<any> {
        return this.http.get('http://localhost:8080/subCategories/get').toPromise()
            .then(data => {
               return data;
            })
            .catch(error => {
                console.log(error)
            })
    }

    addSubcategory(sub:any):Promise <any>{
        return this.http.put('http://localhost:8080/subCategories/save',sub).toPromise()
            .then(data => {
                return data;
            })
            .catch(error => console.log(error))
    }

    updateSubcategory(sub: any): Promise<any>{
         return this.http.put('http://localhost:8080/subCategories/update',sub).toPromise()
            .then()
            .catch(error => console.log(error));
    }

    deleteSubCategory(id: any): Promise<number> {
        return this.http.delete('http://localhost:8080/subCategories/delete/' + id).toPromise()
            .then()
            .catch(error => {
                console.log(error)
            });
    }

    //method with products

    getProducts(): Promise<any>{
        return this.http.get('http://localhost:8080/commodities/get').toPromise()
            .then(data=>{
                return data;
            })
            .catch(error=>{
                console.log(error)
            })
    }
    addProduct(prod:any): Promise<any>{
        return this.http.put('http://localhost:8080/commodities/save',prod).toPromise()
            .then(data=>{
                return data;
            })
            .catch(error=>{
                console.log(error)
            });
    }

    deleteProduct(id: number){
        return this.http.delete('http://localhost:8080/commodities/delete/' + id).toPromise()
            .then()
            .catch(error => {
                console.log(error)
            });
    }

    updateProduct(prod:any): Promise<any>{
        return this.http.put('http://localhost:8080/commodities/update',prod).toPromise()
            .then(data => {
                return data;
            })
            .catch(error => console.log(error))
    }

    //method with orders


    getOrder(){
        return this.http.getOrd('http://localhost:8080/orders/get').toPromise()
            .then(data=>{return data})
            .catch(error => console.log(error))
    }

    addOrder(order:any):Promise<any>{
        return this.http.put('http://localhost:8080/orders/order',order).toPromise()
            .then(data=>{
                return data;
            })
            .catch(error=> console.log(error))
    }
    deleteOrder(id:any):Promise<any>{
        return this.http.delete('http://localhost:8080/orders/delete/' + id).toPromise()
            .then()
            .catch(error=>console.log(error))
    }

    archiveOrder(ord:any):Promise<any>{
        let body = JSON.stringify(ord.id);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');
        return this.http.put('http://localhost:8080/orders/archived',body).toPromise()
            .then()
            .catch(error=>console.log(error))
    }

    unArchiveOrder(ord:any):Promise<any>{
        let body = JSON.stringify(ord.id);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');
        return this.http.put('http://localhost:8080/orders/unarchived',body)
            .toPromise()
            .then()
            .catch(error=>console.log(error))
    }




    logOut() {
           this.http.logOut()
        this.router.navigate(['loginAdmin']);
    }

}
