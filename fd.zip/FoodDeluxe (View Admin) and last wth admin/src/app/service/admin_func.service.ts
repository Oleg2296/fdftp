import { Injectable } from '@angular/core'
import 'rxjs/add/operator/toPromise';

import { Orders, Order } from "../admin_user/orders";
import { User, users } from '../admin_user/users';
import { AuthService } from './auth.service';
import { HttpClient } from './http.service';
import 'rxjs/add/operator/toPromise';

import { Category ,categories, Subcategory, subcategories } from '../adminPage/category/categoryes';
import { products } from '../adminPage/products/products';


@Injectable()

export class AdminFunck {
//Orders
    private orders: any = Orders;
    private archOrd: any[]=[];
//users
    private users: User[] = users;
//Categories
    private categories: any[] = categories;
//subCategories
    private subCategories: any[] = subcategories;
//products
    private products: any[] = products;
    private subId: any;
    private MainFilter: any;
    private price: any ={
        price: 0
    }
    private doneOrder: any = {
        done: true
    };
    private ordsProd: any[] = [];

    constructor(private http: HttpClient){}

    doneOrd(){
        return this.doneOrder;
    }
    goDoOrder(){
        if(!this.doneOrder.done){
            this.doneOrder.done=!this.doneOrder.done;
        }

    }

//methods with Orders in cart

    deleteOrderProd(ord:any){
        for(let i=0;i < this.ordsProd.length;i++){
            if(this.ordsProd[i].id==ord.id){
                this.ordsProd.splice(i,1)
            }
        }
    }

    pushOrds(ord:any){
        for(let i=0;i < this.ordsProd.length;i++){
            if(this.ordsProd[i].id==ord.id){
                this.ordsProd[i].count++;
                this.price.price+=this.ordsProd[i].price;
                return;
            }
        }
        this.price.price+=ord.price;
        ord.count = 1;
        this.ordsProd.push(ord);

    }
    getOrdProd(){
        return this.ordsProd;
    }

    getPrice(){
        return this.price;
    }

    //METHOD with orders


    getOrders():Promise<any>{
        return this.http.getOrder()
            .then(data=>{
                let obj = JSON.parse(data["_body"]);
                for(let i=0;i<obj.length; i++){
                    if(!obj[i].archive){
                        this.orders.push(obj[i]);
                    }else{
                        this.archOrd.push(obj[i]);
                    }

                }
                return Promise.resolve(this.orders);
            })
    }

    addOrder(order:any){
        this.http.addOrder(order)
            .then(data=>{
                let obj = JSON.parse(data["_body"]);
                this.orders.push(obj);
            })
    }

    archOrder(ord:any){
        this.http.archiveOrder(ord).then(()=>{
            ord.archive=true;
            for(let i=0;i < this.orders.length;i++){
                if(this.orders[i].id==ord.id){
                    this.archOrd.push(ord);
                    this.orders.splice(i,1);
                }
            }
        })
    }

    unArchOrder(ord:any){
        this.http.unArchiveOrder(ord).then(()=>{
            ord.archive=false;
            for(let i=0;i < this.archOrd.length;i++){
                if(this.archOrd[i].id==ord.id){
                    this.orders.push(ord);
                    this.archOrd.splice(i,1);
                }
            }
        })
    }


    deleteOrder(id:number){
        this.http.deleteOrder(id).then(()=>{
            for(let i=0;i < this.archOrd.length;i++){
                if(this.archOrd[i].id==id){
                    this.archOrd.splice(i,1);
                }
            }
        })
    }

    getArchOrd(){
        return this.archOrd;
    }


//methods with Users

    delete(user: any){
        for(let i=0;i < this.users.length;i++){
            if(user.name == this.users[i].name){
                this.users.splice(i, 1);
            }
        }
    }

    addUser(user: User){
        console.log(user);
        this.users.push(user);
    }


    // method with filters

    setFilterFromMain(prod:any){
        this.MainFilter=prod;
    }

    getMainFilter(){
        return this.MainFilter;
    }

    getSubId():Promise<any>{
        return this.http.getSubCategories().then(data=>{
            var obj = JSON.parse(data["_body"]);
            this.subId=obj[0];
            return Promise.resolve(this.subId);
        })
    }


//methods with Categories

    getCategories():Promise<any>{
        return this.http.getCat().then(data => {
            let obj: any = JSON.parse(data["_body"]);
            for(let i = 0;i<obj.length;i++){
                this.categories[i]=obj[i];
            }
            return Promise.resolve(this.categories);

        });
    }



    updateCategory(category: any){
        this.http.updateCategory(category).then(data=>{
            let obj: any = JSON.parse(data["_body"]);
            for(let i=0;i < this.categories.length;i++){
                if(this.categories[i].id == obj.id){
                    this.categories.splice(i,1,obj);
                }
            }
        })
    }

    addCategory(category: Category):void{
        this.http.addCategory(category).then(data=>{
            let obj: any = JSON.parse(data["_body"]);
            this.categories.push(obj);
        })
    }

    deleteCategory(id: any) {
        this.http.deleteCategory(id)
            .then(()=>{
                for (let i = 0; i < this.categories.length; i++) {
                    if (this.categories[i].id == id) {
                        this.categories.splice(i, 1);
                    }
                }
            })
    }

//methods whit subCategory

    getSubCategories(): Promise<any>{
        return this.http.getSubCategories().then(data => {
            let obj = JSON.parse(data["_body"]);
            for(let i = 0; i<obj.length;i++){
                this.subCategories[i]=obj[i];
            }
            return Promise.resolve(this.subCategories);
        })
    }


    addSubCategory(subCat: Subcategory){
        this.http.addSubcategory(subCat).then(data=> {
            let obj = JSON.parse(data["_body"]);
            this.subCategories.push(obj);
        })
    }

    updateSubcategory(sub: any){
        this.http.updateSubcategory(sub)
            .then(data=>{
                let obj = JSON.parse(data["_body"]);
                for (let i=0;i < this.subCategories.length;i++){
                    if(this.subCategories[i].id==obj.id){
                        this.subCategories.splice(i,1,obj);
                    }
                }
            })
    }

    deleteSubCategory(subId: any){
        this.http.deleteSubCategory(subId).then(()=>{
            for(let i=0;i < this.subCategories.length;i++){
                if(this.subCategories[i].id==subId){
                    this.subCategories.splice(i,1);
                }
            }
        })
    }

//method with products


    getProducts(): Promise<any>{
        return this.http.getProducts()
            .then(data=>{
                var obj = JSON.parse(data["_body"]);
                for(var i in obj){
                    this.products[i]=obj[i];
                }
                return Promise.resolve(this.products);
            })
    }

    addProduct(prod: any){
        this.http.addProduct(prod)
            .then((data:any)=>{
                var obj = JSON.parse(data["_body"]);
                this.products.push(obj);
            })
    }

    delitProduct(prod: any){
        this.http.deleteProduct(prod)
            .then(()=>{
                for(let i=0;i < this.products.length;i++){
                    if(this.products[i].id == prod){
                        this.products.splice(i,1);
                    }
                }
            })
    }

    editSaveProduct(prod: any){
        this.http.updateProduct(prod)
            .then(data=>{
                var obj = JSON.parse(data["_body"]);
                for(let i=0;i < this.products.length;i++){
                    if(this.products[i].id == obj.id){
                        this.products.splice(i,1,obj);
                    }
                }
            })

    }


}


