"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/toPromise');
var router_1 = require('@angular/router');
var auth_service_1 = require('./auth.service');
//users, admins
var userAdmin_1 = require('../admin_user/userAdmin');
var users_1 = require('../admin_user/users');
var categoryes_1 = require("../adminPage/category/categoryes");
var HttpClient = (function () {
    // constructor(private http: Http, private router: Router) {
    // }
    function HttpClient(http, router) {
        this.http = http;
        this.router = router;
        this.admin = userAdmin_1.Admin;
        this.users = users_1.users;
        this.categories = categoryes_1.categories;
    }
    HttpClient.prototype.post = function (url, data) {
        var user = data;
        if (user.login == this.admin.login && user.password == this.admin.password) {
            return true;
        }
        else {
            return false;
        }
    };
    //login
    HttpClient.prototype.loginIn = function (user) {
        var _this = this;
        return this.http.post('http://localhost:8080/login', user).toPromise()
            .then(function (data) {
            var obj = JSON.parse(data["_body"]);
            _this.http.setToken(obj.token);
        });
    };
    HttpClient.prototype.getToken = function () {
        return this.http.getToken();
    };
    //Methods with Categories
    HttpClient.prototype.getCat = function () {
        return this.http.get('http://localhost:8080/categories/get').toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.addCategory = function (category) {
        return this.http.put('http://localhost:8080/categories/save', category).toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.deleteCategory = function (id) {
        return this.http.delete('http://localhost:8080/categories/delete/' + id).toPromise()
            .then()
            .catch(function (error) {
            console.log(error);
        });
    };
    HttpClient.prototype.updateCategory = function (category) {
        return this.http.put('http://localhost:8080/categories/update', category).toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) {
            console.log(error);
        });
    };
    //method with subcategories
    HttpClient.prototype.getSubCategories = function () {
        return this.http.get('http://localhost:8080/subCategories/get').toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) {
            console.log(error);
        });
    };
    HttpClient.prototype.addSubcategory = function (sub) {
        return this.http.put('http://localhost:8080/subCategories/save', sub).toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.updateSubcategory = function (sub) {
        return this.http.put('http://localhost:8080/subCategories/update', sub).toPromise()
            .then()
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.deleteSubCategory = function (id) {
        return this.http.delete('http://localhost:8080/subCategories/delete/' + id).toPromise()
            .then()
            .catch(function (error) {
            console.log(error);
        });
    };
    //method with products
    HttpClient.prototype.getProducts = function () {
        return this.http.get('http://localhost:8080/commodities/get').toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) {
            console.log(error);
        });
    };
    HttpClient.prototype.addProduct = function (prod) {
        return this.http.put('http://localhost:8080/commodities/save', prod).toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) {
            console.log(error);
        });
    };
    HttpClient.prototype.deleteProduct = function (id) {
        return this.http.delete('http://localhost:8080/commodities/delete/' + id).toPromise()
            .then()
            .catch(function (error) {
            console.log(error);
        });
    };
    HttpClient.prototype.updateProduct = function (prod) {
        return this.http.put('http://localhost:8080/commodities/update', prod).toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) { return console.log(error); });
    };
    //method with orders
    HttpClient.prototype.getOrder = function () {
        return this.http.getOrd('http://localhost:8080/orders/get').toPromise()
            .then(function (data) { return data; })
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.addOrder = function (order) {
        return this.http.put('http://localhost:8080/orders/order', order).toPromise()
            .then(function (data) {
            return data;
        })
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.deleteOrder = function (id) {
        return this.http.delete('http://localhost:8080/orders/delete/' + id).toPromise()
            .then()
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.archiveOrder = function (ord) {
        var body = JSON.stringify(ord.id);
        var headers = new http_1.Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');
        return this.http.put('http://localhost:8080/orders/archived', body).toPromise()
            .then()
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.unArchiveOrder = function (ord) {
        var body = JSON.stringify(ord.id);
        var headers = new http_1.Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');
        return this.http.put('http://localhost:8080/orders/unarchived', body)
            .toPromise()
            .then()
            .catch(function (error) { return console.log(error); });
    };
    HttpClient.prototype.logOut = function () {
        this.http.logOut();
        this.router.navigate(['loginAdmin']);
    };
    HttpClient = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [auth_service_1.AuthService, router_1.Router])
    ], HttpClient);
    return HttpClient;
}());
exports.HttpClient = HttpClient;
//# sourceMappingURL=http.service.js.map