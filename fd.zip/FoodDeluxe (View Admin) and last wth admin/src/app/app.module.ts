//Modules
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ReactiveFormsModule } from "@angular/forms";
// import { ModalModule } from "ng2-modal";

import { AgmCoreModule, MapsAPILoader } from 'angular2-google-maps/core';
//Router module
import { AppRoutingModule } from './app.router';
import {Ng2PageScrollModule} from 'ng2-page-scroll';

//Components
// import { AddUserComponent } from './adminPage/addUsers/addUsr.component';
import { AppComponent } from './app.component';
import { LoginAdminComponent } from './loginAdmin/loginAdmin.component';
import { AdminPageComponent } from './adminPage/adminPage.component';
import { OrdersComponent } from './adminPage/orders/orders.component';
import { CategoryComponent } from './adminPage/category/category.component';
import { ProductComponent } from './adminPage/products/product.component';
import { SubcategoryComponent } from './adminPage/category/subCategory/subcategory.component';
import { HomePageComponent } from './homePage/home.page.component';
import { NavbarComponent } from './homePage/components/navbar.component';
import { MainComponent } from './homePage/components/main.component';
import { FooterComponent } from './homePage/components/footer.component';
import { MenuComponent } from './homePage/components/menu.component';
import { CartComponent } from './homePage/components/cart.component';
import { ModalComponent } from './homePage/components/modal.order.component';





//Services
// import { AddUserService } from './adminPage/addUsers/addUser.service'
import { HttpClient } from './service/http.service';
import { UserService } from './service/user.service';
import { AuthService } from './service/auth.service';
import { AdminFunck } from './service/admin_func.service';

//Filters
import { MyPipe } from './adminPage/products/products.pipe';
import { SortPipe } from './adminPage/orders/order.pipe';
import { MovieFilterPipe } from './adminPage/orders/serch.pipe.order';
import { SearchProdPipe } from './adminPage/products/pipe.search';
import { PipeProduct } from './homePage/components/pipe.products'
import { PipeCategory } from './homePage/components/pipe.category'


@NgModule({
    imports: [ BrowserModule, FormsModule, HttpModule, AppRoutingModule, Ng2PageScrollModule.forRoot(), AgmCoreModule.forRoot({
        libraries: ["places"],
        apiKey: "AIzaSyC8r1Rdnau0NpihEJXKEo4EaHwwtNdEQJo"
    }), BrowserModule,
        ReactiveFormsModule],
    declarations: [ AppComponent, LoginAdminComponent, AdminPageComponent, OrdersComponent, CategoryComponent,ProductComponent,SubcategoryComponent, MyPipe, SortPipe, MovieFilterPipe,FooterComponent, SearchProdPipe,MainComponent, HomePageComponent, NavbarComponent, MenuComponent, CartComponent, PipeProduct, PipeCategory,ModalComponent],
    providers: [ UserService, HttpClient, AuthService, AdminFunck],
    bootstrap: [ AppComponent ]
})

export class AppModule { }