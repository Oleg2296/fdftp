
//modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders }  from '@angular/core';

//Components
// import { AddUserComponent } from './adminPage/addUsers/addUsr.component';
import { LoginAdminComponent } from './loginAdmin/loginAdmin.component';
import { AdminPageComponent } from './adminPage/adminPage.component';
import { OrdersComponent } from './adminPage/orders/orders.component';
import { CategoryComponent } from './adminPage/category/category.component';
import { ProductComponent } from './adminPage/products/product.component';
import { SubcategoryComponent } from './adminPage/category/subCategory/subcategory.component';
import { HomePageComponent } from './homePage/home.page.component';
import { MenuComponent } from './homePage/components/menu.component';
import { MainComponent } from './homePage/components/main.component';
import { ModalComponent } from './homePage/components/modal.order.component'
//Services
// import { AddUserService } from './adminPage/addUsers/addUser.service'
import { AdminPageService } from './adminPage/adminPage.service';
import { LoginAdminService } from './loginAdmin/loginAdmin.service';




const childRout: Routes =  [
  { path: "orders", component: OrdersComponent},
  { path: "category", component: CategoryComponent},
  { path: "products", component: ProductComponent },
  { path: "subcategory", component: SubcategoryComponent }

  ];

const routes: Routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    { path: 'loginAdmin', component: LoginAdminComponent },
    { path: 'home', component: HomePageComponent,
    children:[
        {
    path: 'menu', component: MenuComponent
    },{
    path: 'order', component: ModalComponent
    }
    ,  { path: '', component: MainComponent, pathMatch: 'full'
    //
    }
    ]
    },
    { path: 'adminPage', component: AdminPageComponent,
        children: childRout
    }
];

const Router: ModuleWithProviders = RouterModule.forRoot(routes);


@NgModule({
    imports: [Router],
    providers: [ AdminPageService, LoginAdminService],
    exports: [RouterModule]

})

export class AppRoutingModule {}


// { path: 'adminPage',
//     component: AdminPageComponent,
//     children: [
//     {
//         path: 'orders',
//         component: OrdersComponent
//     }
// ]
// }
