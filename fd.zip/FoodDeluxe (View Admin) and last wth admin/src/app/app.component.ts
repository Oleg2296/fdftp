import { Component } from '@angular/core';

import { UserService } from './service/user.service';
import { HttpClient } from './service/http.service';

@Component({
    selector: 'my-app',
    providers: [ UserService, HttpClient],
    template: "<router-outlet></router-outlet>"
})

export class AppComponent{
    constructor(private userService: UserService){}
}

